// import { UsersData } from "./components/UsersData";

import { RegistrationForm } from "./components/RegistrationForm"
import { UsersRecord } from "./components/UsersRecord"

function App() {
 
  return (
    <div>
      {/* <UsersData></UsersData> */}
      <RegistrationForm></RegistrationForm>
    <UsersRecord></UsersRecord>
    </div>
  )
}

export default App
