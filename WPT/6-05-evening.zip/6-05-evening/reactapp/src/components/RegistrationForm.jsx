import axios from "axios";
import { useState } from "react"

export function RegistrationForm() {

    const [formData,setFormData] = useState({id:'',name:'',phone:'',marks:''});

    const handleChange = (event)=>{
        setFormData({
            ...formData,
            [event.target.name]:event.target.value
        });
    }

    const handleSubmit = async (event)=>{
        try {
            event.preventDefault();
            console.log(formData);
            const response = await axios.post("http://127.0.0.1:7800/student",formData);
            console.log(response);
        } catch (error) {
            console.log(error);
        }
       
    }

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>id</label>
                    <input type="text" placeholder="enter id" onChange={handleChange} name="id"></input>
                </div>
                <div>
                    <label>name</label>
                    <input type="text" placeholder="enter name" onChange={handleChange} name="name"></input>
                </div>
                <div>
                    <label>phone</label>
                    <input type="text" placeholder="enter phone" onChange={handleChange} name="phone"></input>
                </div>
                <div>
                    <label>marks</label>
                    <input type="text" placeholder="enter marks" onChange={handleChange} name="marks"></input>
                </div>
                <button>Register</button>
            </form>


        </div>
    )
}