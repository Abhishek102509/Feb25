import { Component } from "react";

export class MyComponent extends Component{

    render(){ // it delivers the UI for this class component
        return (
            <div>
                <h1>Welcome to my component</h1>
                
            </div>
        )
    }
}