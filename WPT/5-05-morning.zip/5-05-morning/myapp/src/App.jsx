import { MyComponent } from "./MyComponent";

function App() {
  return (
    <div>
      <h1>Hello World</h1>
      <MyComponent></MyComponent>
    </div>
  )
}

export default App
